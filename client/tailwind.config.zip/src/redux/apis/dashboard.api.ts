import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"
import { RootState } from "../store";

export interface IDashboard {
    income: {
        totalAmount?: number
        month?: number
        year?: number
    },
    patients: {
        newPatients?: number
        oldPatients?: number
        month?: number
        year?: number
    }
}

export const dashBoardApi = createApi({
    reducerPath: "dashBoardApi",
    baseQuery: fetchBaseQuery({
        baseUrl: "http://localhost:5000/api/v1/admin",
        credentials: "include",
        prepareHeaders(headers, { getState }) {
            const state = getState() as RootState

            const token = state.auth?.user?.token
            if (token) {
                headers.set("Authorization", `Bearer ${token}`);
            }

            return headers;
        }
    }),
    tagTypes: ["admin"],
    endpoints: (builder) => {
        return {
            getAdminDashboardData: builder.query<IDashboard, { selectedYear: number }>({
                query: (queryParams) => {
                    return {
                        url: "/dashboard",
                        method: "GET",
                        params: queryParams
                    }
                },
                transformResponse: (data: { result: IDashboard }) => {
                    return data.result
                },
                transformErrorResponse: (error: { status: number, data: { message: string } }) => {
                    return error.data.message
                },
                providesTags: ["admin"]
            }),
        }
    }
})

export const { useGetAdminDashboardDataQuery } = dashBoardApi
