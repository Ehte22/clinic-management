import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDeleteInvoiceMutation, useFetchAllInvoicesQuery } from "../../redux/apis/invoiceApi";
import { ColumnDef } from "@tanstack/react-table";
import TableData from "../../components/TableData";
import { toast } from "../../utils/toast";
import Loader from "../../components/Loader";


const Invoice: React.FC = () => {
    const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 10 });
    const [sorting, setSorting] = useState<any>([]);
    const [globalFilter, setGlobalFilter] = useState("");
    const [deleteInvoice, { error, isError, isSuccess }] = useDeleteInvoiceMutation()

    const columns: ColumnDef<any>[] = [
        {
            header: "Invoice Number",
            accessorKey: "invoiceNumber",
            cell: (info) => info.getValue(),
        },
        {
            header: "Issue Date",
            accessorKey: "issueDate",
            cell: (info) => {
                console.log(info.getValue());

                const value = info.getValue() as string;
                return new Date(value).toLocaleDateString();
            },
        },
        {
            header: "Due Date",
            accessorKey: "dueDate",
            cell: (info) => {
                const value = info.getValue() as string;
                return new Date(value).toLocaleDateString();
            },
        },
        {
            header: "Payment Status",
            accessorKey: "paymentStatus",
            cell: (info) => info.getValue(),
        },
        {
            header: "Total Amount",
            accessorKey: "totalAmount",
            cell: (info) => `₹${info.getValue()}`,
        },
        {
            header: "Items",
            accessorKey: "items",
            cell: (info) =>
                (info.getValue() as Array<any>)
                    .map((item, index) => <div className="" key={index}>
                        <p>{item.description} ({item.quantity}x₹{item.unitPrice})</p>
                    </div>),
        },
        {
            header: "Actions",
            cell: (info) => {
                const row = info.row.original
                const navigate = useNavigate()
                return (
                    <div className="flex gap-10">
                        <button
                            className="text-indigo-600 hover:text-indigo-900"
                            onClick={() => navigate(`/update-invoice/${row._id}`)}
                        >
                            Edit
                        </button>
                        <button
                            className="text-red-600 hover:text-delete-900"
                            onClick={() => deleteInvoice(row._id)}
                        >
                            Delete
                        </button>
                    </div>
                );
            },
        },
    ];

    const navigate = useNavigate();

    const { data, isLoading } = useFetchAllInvoicesQuery({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        sortBy: JSON.stringify(sorting),
        filter: globalFilter,
    })
    useEffect(() => {
        if (isSuccess) {
            toast.showSuccess('Invoice Deleted!')
        }
    }, [isSuccess])
    useEffect(() => {
        if (isError) {
            toast.showError(error as string)
        }
    }, [isError])

    if (isLoading) {
        return <div className="flex justify-center items-center h-screen -mt-20">
            <Loader size={16} />
        </div>
    }
    return (
        <div>
            <div className="sm:flex sm:items-center justify-center">
                <div className="sm:flex-auto">
                    <h2 className="text-lg font-bold text-gray-900">Invoices</h2>
                </div>
                <div className="mt-4 sm:ml-16 sm:mt-0 flex justify-between gap-5">
                    <input
                        type="text"
                        onChange={(e) => setGlobalFilter(e.target.value)}
                        placeholder="Search..."
                        className="block w-72 h-10 rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                    />
                    <button
                        type="button"
                        className="block rounded-md bg-indigo-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        onClick={() => navigate("/add-invoice")}>Add Invoices
                    </button>
                </div>
            </div>

            <div className="mt-8 flow-root">
                <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">

                        <TableData
                            data={data?.data || []}
                            columns={columns}
                            enableSorting={true}
                            enableGlobalFilter={true}
                            initialPagination={pagination}
                            totalRows={Math.ceil((data?.total || 1) / pagination.pageSize)}
                            onPaginationChange={setPagination}
                            onSortingChange={setSorting}
                            onGlobalFilterChange={globalFilter}
                            totalPages={Math.ceil((data?.total || 1) / pagination.pageSize)}
                        />

                    </div>
                </div>
            </div>
        </div >
    );
};

export default Invoice;
