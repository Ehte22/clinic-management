


import useDynamicForm from "../components/useDynamicForm";
import { FieldConfig } from "../models/fieldConfig.interface";
import { customValidator } from "../utils/validator";
import { useAddCreatePatientMutation, useGetPatientByIdQuery, useUpdatePatientMutation, } from "../redux/apis/patientApi";
import { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "../utils/toast";


const defaultValues = {
    name: "",
    dateOfBirth: "",
    gender: "",
    contactInfo: "",
    email: "",
    age: "",
    weight: "",
    address: {
        city: "",
        state: "",
        country: "",
        street: "",
        zipCode: "",
    },

    emergencyContact: {
        name: "",
        relationship: "",
        contactNumber: "",
    },
};

const Patient = () => {
    const { id } = useParams()
    const navigate = useNavigate()


    const [addPatient, { isSuccess, isError }] = useAddCreatePatientMutation();

    const { data: patientData, } = useGetPatientByIdQuery(id || "", {

        skip: !id,
    })
    const [updatePatient] = useUpdatePatientMutation()




    useEffect(() => {
        if (isSuccess) {
            toast.showSuccess("Patient Added Success")
        }
    }, [isSuccess])
    useEffect(() => {
        if (isError) {
            toast.showError("Patient Eror Success")
        }
    }, [isError])

    const fields: FieldConfig[] = [

        {
            name: "name",
            label: "Name",
            type: "text",
            placeholder: "Enter Paitent Name",
            rules: { required: true },
        },
        {
            name: "dateOfBirth",
            label: "Date of Birth",
            type: "date",
            rules: { required: true },
        },
        {
            name: "gender",
            label: "Gender",
            type: "radio",
            options: [
                { label: "Male", value: "male" },
                { label: "Female", value: "female" },
                { label: "Other", value: "other" },
            ],
            rules: { required: true },
        },

        {
            name: "contactInfo",
            label: "Contact Info",
            type: "text",
            rules: { required: true },
            placeholder: "Enter Contact Info "
        },
        {
            name: "email",
            label: "Email Address",
            type: "text",
            rules: { required: false, email: true },
            placeholder: "Enter Email Address"
        },
        {
            name: "age",
            label: "Age",
            type: "text",
            rules: { required: true },
            placeholder: "Enter Age"
        },
        {
            name: "weight",
            label: "Weight",
            type: "text",
            rules: { required: true },
            placeholder: "Enter Weight"
        },
        {
            name: "address",
            type: "formGroup",
            object: true,
            formGroup: {
                city: {
                    name: "city",
                    label: "City",
                    type: "text",
                    className: "sm:col-span-3 xl:col-span-2 mb-5",
                    rules: { required: true },
                    placeholder: "Enter City"
                },
                state: {
                    name: "state",
                    label: "State",
                    type: "text",
                    placeholder: "Enter amount",
                    className: "sm:col-span-3 xl:col-span-2 mb-5",
                    rules: { required: false },
                },
                country: {
                    name: "country",
                    label: "Country",
                    className: "sm:col-span-3 xl:col-span-2 mb-5",
                    type: "select",
                    options: [
                        { label: "Select Country", value: "", disabled: true },
                        { label: "India", value: 'india' },
                        { label: "United States", value: "United States" },
                        { label: "United Kingdom", value: "United Kingdom" },
                        { label: "Australia", value: "Australia" },
                    ],
                    rules: { required: false },
                },
                zipCode: {
                    name: "zipCode",
                    label: "Zip Code",
                    type: "text",
                    className: "sm:col-span-3 xl:col-span-2",
                    rules: { required: false },
                    placeholder: "Enter Zip Code"
                },
                street: {
                    name: "street",
                    label: "Street Address",
                    type: "textarea",
                    className: "sm:col-span-6 xl:col-span-4 mb-5 xl:mb-0",

                    rules: { required: false },
                    placeholder: "Enter Street Address"
                },
            },
            rules: {},
        },

        {
            name: "emergencyContact",
            displayName: "Emergency Contact",
            type: "formGroup",
            object: true,
            formGroup: {
                name: {
                    name: "name",
                    label: "Name",
                    type: "text",
                    className: "sm:col-span-3 xl:col-span-2 mb-5",
                    rules: { required: true },
                    placeholder: "Enter Name"
                },
                relationship: {
                    name: "relationship",
                    label: "Relationship",
                    className: "sm:col-span-3 xl:col-span-2 mb-5 xl:mb-0",
                    type: "text",
                    rules: { required: true },
                    placeholder: "Enter Relationship"
                },
                contactNumber: {
                    name: "contactNumber",
                    label: "Contact Number",
                    className: "sm:col-span-3 xl:col-span-2 mb-5 xl:mb-0",
                    type: "text",
                    rules: { required: true },
                    placeholder: "Enter Contact Number"
                },
            },
            rules: {},
        },

    ];

    const schema = customValidator(fields);
    const onSubmit = async (data: any) => {

        if (id && patientData) {
            updatePatient({ updatepatient: data, updatedPatient: id })
        } else {
            addPatient(data)
        }
    };


    useEffect(() => {
        if (id && patientData) {
            setValue("name", patientData.name)
            setValue("dateOfBirth", patientData.dateOfBirth)
            setValue("gender", patientData?.gender)
            setValue("contactInfo", patientData.contactInfo)
            setValue("email", patientData.email)
            setValue("age", patientData.age.toString() || "")
            setValue("weight", patientData.weight.toString() || "")
            setValue("address.city", patientData.address?.city);
            setValue("address.state", patientData.address?.state || "");
            setValue("address.country", patientData.address?.country || "");
            setValue("address.street", patientData.address?.street || "");
            setValue("address.zipCode", patientData.address?.zipCode || "");
            setValue("emergencyContact.name", patientData.emergencyContact?.name || "");
            setValue("emergencyContact.relationship", patientData.emergencyContact?.relationship || "");
            setValue("emergencyContact.contactNumber", patientData.emergencyContact?.contactNumber || "");
        }

    },
        [patientData])


    const { renderSingleInput, handleSubmit, reset, setValue, watch, disableField } = useDynamicForm({
        schema,
        fields,
        onSubmit,
        defaultValues,
    });

    const { dateOfBirth } = watch()

    useEffect(() => {
        if (dateOfBirth) {
            const birthDate = new Date(dateOfBirth)
            const today = new Date()
            const age = today.getFullYear() - birthDate.getFullYear()

            if (age) {
                setValue("age", age.toString())
                disableField("age", true)
            }
        }
    }, [dateOfBirth])

    return <>

        <div className="grid grid-cols-1 gap-x-8 gap-y-8">
            <div className="flex justify-between">
                <h2 className="text-lg font-bold text-gray-900">{id ? "Update Patient" : "Add Patient"}</h2>
                <button
                    type="button"
                    className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    onClick={() => navigate("/patients")}
                >
                    Back
                </button>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl">
                <div className="px-4 py-6 sm:p-8">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("name")}
                        </div>

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("dateOfBirth")}
                        </div>


                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("contactInfo")}
                        </div>

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("email")}
                        </div>

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("age")}
                        </div>

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("weight")}
                        </div>

                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput("gender")}
                        </div>

                        <div className="sm:col-span-6">
                            {renderSingleInput("address")}
                        </div>

                        <div className="sm:col-span-6">
                            {renderSingleInput("emergencyContact")}
                        </div>


                    </div>
                </div>

                <div className="flex items-center justify-end gap-x-3 border-t border-gray-900/10 px-4 py-4 sm:px-8">
                    <button onClick={() => reset()} type="button" className="rounded-md bg-gray-400 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Save
                    </button>
                </div>
            </form>


        </div >
    </>
};

export default Patient;
















