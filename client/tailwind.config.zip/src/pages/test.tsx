// import { z } from "zod";
// import { FieldConfig } from "./useDynamicForm";
// import { customValidator, ValidationRules } from "./validator";
// import { useAddFormMutation } from "./redux/userApi";
// import useDynamicForm from "./useDynamicForm";

// const fields: FieldConfig[] = [
//     {
//         name: "username",
//         label: "Username",
//         type: "text",
//         placeholder: "Enter your username",
//         // className: "form-control col-md-6 col-lg-4",
//         rules: { required: true, min: 2, max: 16 }
//     },
//     {
//         name: "email",
//         label: "Email",
//         type: "email",
//         placeholder: "Enter your email",
//         // className: "form-control col-md-6 col-lg-4",
//         className: "form-control",
//         rules: { required: true, email: true }
//     },
//     {
//         name: "phone",
//         label: "Phone Number",
//         type: "text",
//         placeholder: "Enter your phone number",
//         // className: "form-control col-md-6 col-lg-4",
//         className: "form-control",
//         rules: { required: true, pattern: /^[6-9]\d{9}$/ }
//     },
//     {
//         name: "gender",
//         legend: "Gender",
//         text: "Lorem Ipsum dolor sit ame.",
//         type: "radio",
//         options: [
//             { label: "Male", value: "male" },
//             { label: "Female", value: "female" },
//         ],
//         // className: "form-check-input col-md-6 col-lg-4",
//         className: "form-check-input",
//         rules: { required: true }
//     },
//     {
//         name: "hobbies",
//         label: "Hobbies",
//         type: "checkbox",
//         options: [
//             { label: "Reading", value: "reading", description: "lorem ipsum dolor sit amet." },
//             { label: "Traveling", value: "traveling", description: "lorem ipsum dolor sit amet." },
//             { label: "Gaming", value: "gaming", description: "lorem ipsum dolor sit amet." },
//         ],
//         className: "form-check-input col-md-6 col-lg-4",
//         rules: { required: false, checkbox: true }
//     },
//     {
//         name: "profile",
//         label: "Profile",
//         type: "file",
//         accept: "image/*",
//         multiple: true,
//         // className: "form-control col-md-6 col-lg-4",
//         className: "form-control",
//         rules: { required: true, file: true, accept: ["image/png", "image/jpeg"], maxSize: 2 }
//     },
//     {
//         name: "country",
//         label: "Country",
//         type: "select",
//         options: [
//             { name: "Select Country", disabled: true },
//             { name: "India" },
//             { name: "America" },
//             { name: "Germany" }
//         ],
//         // className: "form-select col-md-6 col-lg-4",
//         className: "form-select",
//         rules: { required: true }
//     },
//     {
//         name: "desc",
//         label: "Description",
//         type: "textarea",
//         className: "form-control",
//         placeholder: "Enter text here",
//         rows: 4,
//         rules: { required: false, min: 5, max: 100 }
//     },
//     {
//         name: "experience",
//         displayName: "Experience",
//         type: "formArray",
//         className: "border",
//         formArray: [
//             {
//                 name: "company",
//                 label: "Company Name",
//                 placeholder: "Enter company name",
//                 type: "text",
//                 className: "sm:col-span-3",
//                 rules: { required: true }
//             },
//             {
//                 name: "position",
//                 label: "Position",
//                 type: "select",
//                 options: [
//                     { name: "Select Position", disabled: true },
//                     { name: "Junior Developer" },
//                     { name: "Senior Developer" },
//                     { name: "Software Developer" },
//                     { name: "Team Lead" }
//                 ],
//                 className: "sm:col-span-3",
//                 rules: { required: true }
//             },
//             {
//                 name: "start",
//                 label: "Start Date",
//                 type: "date",
//                 className: "sm:col-span-3",
//                 rules: { required: true }
//             },
//             {
//                 name: "end",
//                 label: "End Date",
//                 type: "date",
//                 className: "sm:col-span-3",
//                 rules: { required: true }
//             }
//         ],
//         rules: {}
//     },
//     {
//         name: "button",
//         displayName: "Add User",
//         type: "submit",
//         className: "btn btn-dark text-end my-3 me-4",
//         rules: {}
//     },

//     {
//         name: "address",
//         type: "formGroup",
//         object: true,
//         formGroup: {
//             street: {
//                 name: "street",
//                 label: "Street",
//                 placeholder: "Enter Street",
//                 type: "text",
//                 className: "sm:col-span-3",
//                 rules: { required: true }
//             },
//             city: {
//                 name: "city",
//                 label: "City",
//                 placeholder: "Enter City",
//                 type: "text",
//                 className: "sm:col-span-3 ",
//                 rules: { required: true }
//             },
//         },
//         rules: {}
//     },
// ];

// const defaultValues = {
//     username: "",
//     email: "",
//     phone: "",
//     gender: "",
//     country: "",
//     hobbies: "",
//     profile: "",
//     desc: "",
//     experience: [{
//         company: "",
//         position: "",
//         start: "",
//         end: "",
//     }],
//     address: {
//         street: "",
//         city: "",
//     },
//     button: ""
// }

// export interface ExtractedRule {
//     name: string;
//     rules: ValidationRules | ExtractedRule[];
// }

// const App = () => {
//     const [addUser] = useAddFormMutation()

//     const schema = customValidator(fields)

//     type FormValues = z.infer<typeof schema>

//     const onSubmit = (values: FormValues) => {
//         console.log(values);

//         const fd = new FormData();

//         Object.keys(values).forEach((key) => {
//             if (key === "hobbies") {
//                 if (values[key].length > 1) {
//                     values[key].forEach((item: string) => {
//                         fd.append(key, item)
//                     })
//                 } else {
//                     fd.append(key, values[key]);
//                 }
//             } else if (key === "experience") {
//                 values[key].forEach((item: Record<string, string>, index: number) => {
//                     Object.keys(item).forEach((subKey: string) => {
//                         fd.append(`${key}[${index}][${subKey}], item[subKey]`);
//                     })
//                 })
//             } else if (key === "profile") {
//                 Object.keys(values.profile).forEach((item) => {
//                     fd.append(key, values.profile[item])
//                 })
//             } else {
//                 fd.append(key, values[key]);
//             }
//         })

//         addUser(fd)
//     };

//     const { renderSingleInput, handleSubmit, previewImages, errors } = useDynamicForm({ schema, fields, onSubmit, defaultValues })
//     console.log(errors);


//     return <>
//     </>
// };

// export default App