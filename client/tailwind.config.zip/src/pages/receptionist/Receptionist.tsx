import React, { useEffect, useState } from "react";
import { useChangeReceptionistStatusMutation, useDeleteReceptionistMutation, useGetAllReceptionistsQuery } from "../../redux/apis/receptionistApi";
import { ColumnDef } from "@tanstack/react-table";
import { useNavigate } from "react-router-dom";
import TableData from "../../components/TableData";
import { format } from 'date-fns'
import { toast } from "../../utils/toast";
import Loader from "../../components/Loader";


const Receptionist: React.FC = () => {
    const [pagination, setPagination] = useState<{ pageIndex: number; pageSize: number }>({ pageIndex: 0, pageSize: 10 });
    const [sorting, setSorting] = useState<any[]>([]);
    const [globalFilter, setGlobalFilter] = useState<string>("");
    const [deleteReceptionist, { isSuccess: isSuccessDelete, error: errorDelete, isError: isErrorDelete }] = useDeleteReceptionistMutation()
    const [changeStatus, { isSuccess, error, isError }] = useChangeReceptionistStatusMutation()
    const navigate = useNavigate()
    const { data, isLoading } = useGetAllReceptionistsQuery({
        page: pagination.pageIndex + 1,
        // limit: 2,
        limit: pagination.pageSize,
        sortBy: JSON.stringify(sorting),
        filter: globalFilter,
    });



    const columns: ColumnDef<any>[] = [
        {
            header: "First Name",
            accessorKey: "user.firstName",
            cell: (info) => info.getValue(),
        },
        {
            header: "Last Name",
            accessorKey: "user.lastName",
            cell: (info) => info.getValue(),
        },
        {
            header: "Email",
            accessorKey: "user.email",
            cell: (info) => info.getValue(),
        },
        {
            header: "Phone",
            accessorKey: "user.phone",
            cell: (info) => info.getValue(),
        },
        {
            header: "Working Hours",
            accessorKey: "working_hours",
            cell: (info) => {
                const value = info.getValue() as Array<{ day: string; from: string; to: string }>;
                return value.map((hour, index) => (
                    <div key={index}>
                        <p>
                            {format(new Date(hour.day), "dd-MM-yyyy")}
                            From: {hour.from} To: {hour.to}
                        </p>
                    </div>
                ));
            },
        },
        {
            header: "Status",
            accessorKey: "user.status",
            cell: (info) => {
                const row = info.row.original;
                return (
                    <div className="flex gap-10">
                        <button
                            className="text-indigo-600 hover:text-indigo-900"
                            onClick={async () => {
                                await changeStatus({
                                    id: row._id,
                                    status: row?.user.status === 'active' ? 'inactive' : 'active',
                                })
                            }}
                        >
                            {info.getValue() as string}
                        </button>
                    </div>
                );
            }
        },

        {
            header: "Actions",
            cell: (info) => {
                const row = info.row.original
                const navigate = useNavigate()
                return (
                    <div className="flex gap-10">
                        <button
                            className="text-indigo-600 hover:text-indigo-900"
                            onClick={() => navigate(`/update-receptionist/${row._id}`)}
                        >
                            Edit
                        </button>
                        <button
                            className="text-red-600 hover:text-delete-900"
                            onClick={async () => {
                                await deleteReceptionist(row._id).unwrap()
                            }}
                        >
                            Delete
                        </button>
                    </div>
                );
            },
        },
    ];

    const total = data?.total || 0
    useEffect(() => {
        if (error) {
            toast.showError(error as string)
        } else if (errorDelete) {
            toast.showError(errorDelete as string)
        }
    }, [isError, isErrorDelete])
    useEffect(() => {
        if (isSuccess) {
            toast.showSuccess("Receptionist status Changed!")
        }
    }, [isSuccess])
    useEffect(() => {
        if (isSuccessDelete) {
            toast.showSuccess("Receptionist SuccessFully Deleted!")
        }
    }, [isSuccessDelete])

    if (isLoading) {
        return <div className="flex justify-center items-center h-screen -mt-20">
            <Loader size={16} />
        </div>
    }
    return (
        <div>
            <div className="sm:flex sm:items-center justify-center">
                <div className="sm:flex-auto">
                    <h2 className="text-lg font-bold text-gray-900">Receptionist</h2>
                </div>
                <div className="mt-4 sm:ml-16 sm:mt-0 flex justify-between gap-5">
                    <input
                        type="text"
                        onChange={(e) => setGlobalFilter(e.target.value)}
                        placeholder="Search..."
                        className="block w-72 h-10 rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                    />
                    <button
                        type="button"
                        className="block rounded-md bg-indigo-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        onClick={() => navigate("/add-receptionist")}
                    >
                        Add
                    </button>
                </div>
            </div>

            <div className="mt-8 flow-root">
                <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                        <TableData
                            data={data?.data || []}
                            columns={columns}
                            enableSorting={true}
                            enableGlobalFilter={true}
                            initialPagination={pagination}
                            totalRows={Math.ceil(total / pagination.pageSize)}
                            onPaginationChange={setPagination}
                            onSortingChange={setSorting}
                            onGlobalFilterChange={globalFilter}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Receptionist;
