
// import { FieldConfig } from "../models/fieldConfig.interface";
// import { customValidator } from "../utils/validator";
// import { useEffect, useState } from "react";
// import { GETDATA, useGetAllMedicinesQuery } from "../redux/apis/medicineApi";
// import useDynamicForm from "../components/useDynamicForm";
// import Modal from "./prescription/Modal";
// import { toast } from "../utils/toast";
// import PrescriptionTable from "../components/patient/PrescriptionTable";
// import { useCreatePrescriptionMutation } from "../redux/apis/prescriptionApi";
// import { useTodayPatientsQuery } from "../redux/apis/patientApi";
// import { useSearchDoctorQuery } from "../redux/apis/doctor.api";
// const defaultValues = {
//     patient: "",
//     doctor: "",
//     medical: [{
//         medicine: "",
//         dosage: "",
//         timing: "",
//         duration: "",
//         tests: "",
//         mealRelation: "",
//         quantity: "",

//     }],
//     complete: "",
//     note: "",
//     validUntil: "",
//     add: "",
//     nextDate: "",
//     diagnost: "",
//     weight: "",
//     age: ""
// };

// const Prescription = () => {

//     const [prescriptionOptions, setPrescriptionOptions] = useState<{ label: string, value: string, disabled?: boolean }[]>([
//         { label: "Select Prescription Name", value: "", disabled: true }
//     ]);
//     const [doctorOptions, setDoctorOptions] = useState<{ label: string, value: string, disabled?: boolean }[]>([
//         { label: "Select Doctor Name", value: "", disabled: true }
//     ]);
//     const [medicineOptions, setMedicineOptions] = useState<{ label: string, value: string, disabled?: boolean }[]>([
//         { label: "Select Doctor Name", value: "", disabled: true }
//     ]);
//     const [addPrescription, { isSuccess, isError, }] = useCreatePrescriptionMutation()

//     const { data: prescriptionAlldata, isSuccess: getPrescriptiontSuccess } = useTodayPatientsQuery()
//     console.log("prescriptionAlldata::::", prescriptionAlldata);

//     const { data: docotrAlldata, isSuccess: getDoctorSuccess } = useSearchDoctorQuery({
//         query: "",
//         page: 1,
//         limit: 1000,
//     })

//     const { data: allMedicines, isSuccess: medicineSuccess } = useGetAllMedicinesQuery({
//         page: 1,
//         limit: 10000,
//         filter: ""
//     })




//     const [medicineData, setMedicineData] = useState<GETDATA>()

//     const fields: FieldConfig[] = [
//         {
//             name: "patient",
//             label: "Patient ID",
//             type: "select",
//             className: "form-select",
//             options: prescriptionOptions,
//             rules: { required: true },



//         },
//         {
//             name: "medical",
//             type: "formArray",
//             className: "border",
//             object: true,
//             formArray: [


//                 {
//                     name: "medicine",
//                     label: "Medicine",
//                     type: "text",
//                     className: "sm:col-span-1",
//                     rules: { required: true },
//                 },
//                 {
//                     name: "dosage",
//                     label: "Dosage",
//                     type: "text",
//                     className: "sm:col-span-1",
//                     rules: { required: true },
//                 },
//                 {
//                     name: "duration",
//                     label: "Duration",
//                     type: "text",
//                     className: "sm:col-span-1",
//                     rules: { required: true },
//                 },
//                 {
//                     name: "quantity",
//                     label: "Quantity",
//                     type: "number",
//                     rules: { required: true },
//                 },
//                 {

//                     name: "tests",
//                     label: "TestName",
//                     type: "text",
//                     className: "sm:col-span-1",
//                     rules: { required: false },
//                 },
//                 {
//                     name: "mealRelation",
//                     label: "MealRelation",
//                     type: "select",

//                     options: [
//                         { label: "Before Meal", value: "Before Meal" },
//                         { label: "After Meal", value: "After Meal" },
//                         { label: "Without Meal", value: "Without Meal" },
//                     ],
//                     rules: { required: true, },
//                 },
//                 {
//                     name: "timing",
//                     label: "timing",
//                     type: "checkbox",

//                     options: [
//                         { label: "Morning", value: "Morning" },
//                         { label: "Afternoon", value: "Afternoon" },
//                         { label: "Evening", value: "Evening" },
//                         { label: "Night", value: "Night" },
//                     ],
//                     rules: { required: true, checkbox: true },
//                 },

//             ],
//             rules: {}
//         },

//         {
//             name: "doctor",
//             label: "Doctor ID",
//             type: "select",
//             className: "form-select",
//             options: doctorOptions,
//             rules: { required: true },
//         },



//         {
//             name: "validUntil",
//             label: "Valid Until",
//             type: "date",
//             rules: { required: true },
//         },
//         {
//             name: "nextDate",
//             label: "Next Date",
//             type: "date",
//             rules: { required: false },
//         },
//         {
//             name: "age",
//             label: "Age",
//             type: "number",
//             rules: { required: false },
//         },
//         {
//             name: "weight",
//             label: "Weight",
//             type: "text",
//             rules: { required: false },
//         },


//         {
//             name: "complete",
//             label: "Complete",
//             type: "textarea",
//             rules: { required: false },
//         },
//         {
//             name: "diagnost",
//             label: "Diagnost",
//             type: "textarea",
//             rules: { required: false },
//         },
//         {
//             name: "note",
//             label: "Notes",
//             type: "textarea",
//             rules: { required: false },
//         },


//     ];



//     useEffect(() => {
//         if (Array.isArray(prescriptionAlldata?.result) && getPrescriptiontSuccess) {
//             const prescription = prescriptionAlldata.result.map((prescription: any) => {
//                 return { label: prescription.name, value: prescription.name }
//             });

//             const z = [...prescriptionOptions, ...prescription]
//             setPrescriptionOptions(z)
//         }
//     }, [prescriptionAlldata, getPrescriptiontSuccess]);

//     useEffect(() => {
//         if (docotrAlldata?.result && getDoctorSuccess) {
//             const doctorOptions = docotrAlldata.result?.map((docotor) => {
//                 if (docotor.doctor && docotor.doctor.firstName && docotor.doctor.lastName) {
//                     return { label: docotor.doctor.firstName, value: docotor.doctor.firstName }
//                 } else {
//                     return null;
//                 }
//             }).filter((doctor) => doctor !== null);

//             const doctorName = [...doctorOptions];

//             setDoctorOptions(doctorName);
//         }
//     }, [docotrAlldata, getDoctorSuccess]);

//     useEffect(() => {
//         if (allMedicines) {
//             setMedicineData(allMedicines)
//         }
//     }, [allMedicines, medicineData])


//     useEffect(() => {
//         if (isSuccess) {
//             toast.showSuccess("Patient Added Success")
//         }
//     }, [isSuccess])
//     useEffect(() => {
//         if (isError) {
//             toast.showError("Patient Eror Success")
//         }
//     }, [isError])


//     useEffect(() => {
//         if (allMedicines && medicineSuccess) {
//             const medicine = allMedicines?.result.map((medicine: any) => {

//                 return {

//                     label: `${medicine.medicineName} (${medicine._id})`,
//                     value: medicine._id
//                 };
//             });

//             const y = [...medicineOptions, ...medicine];
//             setMedicineOptions(y);
//         }
//     }, [allMedicines, medicineSuccess]);



//     const schema = customValidator(fields);


//     const onSubmit = (data: any) => {


//         const prescription = prescriptionAlldata?.result?.find(item => item?.name === data?.patient)
//         const docotorData = docotrAlldata?.result?.find(item => {

//             console.log("item?.doctor?.firstName", item?.doctor?.firstName);
//             console.log("data?.doctor", data?.doctor);

//             return item?.doctor?.firstName === data?.doctor

//         })


//         let updatePatient = data
//         updatePatient = { ...data, patient: prescription?._id, doctor: docotorData?._id }
//         addPrescription(updatePatient)
//     };


//     const { renderSingleInput, handleSubmit, setValue, watch } = useDynamicForm({ schema, fields, onSubmit, defaultValues })


//     const [isModalOpen, setIsModalOpen] = useState(false);


//     const handleCloseModal = () => setIsModalOpen(false);
//     watch()
//     // console.log("dymaniccccccccc", watch())

//     return (
//         <>

//             <div>
//                 <button
//                     onClick={() => {
//                         setIsModalOpen(true);
//                     }}
//                     className="inline-flex justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500"
//                 >
//                     Add Prescription
//                 </button>


//                 {isModalOpen && <Modal onClose={handleCloseModal} setValue={setValue} medicineData={medicineData} />}
//             </div>

//             <div className="grid grid-cols-1 gap-x-8 gap-y-8 pt-16 px-24">
//                 <form onSubmit={handleSubmit(onSubmit)}
//                     className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl">
//                     <div className="px-4 py-6 sm:p-8">
//                         <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
//                             <div className="sm:col-span-3 h-16 w-full">{renderSingleInput("patient")}</div>
//                             <div className="sm:col-span-3 h-16 w-full">{renderSingleInput("doctor")}</div>
//                             <div className="sm:col-span-2">{renderSingleInput("age")}</div>
//                             <div className="sm:col-span-2">{renderSingleInput("weight")}</div>
//                             <div className="sm:col-span-6  flex">{renderSingleInput("medical")}</div>
//                             <div className="sm:col-span-3">{renderSingleInput("validUntil")}</div>
//                             <div className="sm:col-span-3">{renderSingleInput("nextDate")}</div>
//                             <div className="sm:col-span-6">{renderSingleInput("complete")}</div>
//                             <div className="sm:col-span-6">{renderSingleInput("diagnost")}</div>
//                             <div className="sm:col-span-6">{renderSingleInput("note")}</div>
//                         </div>
//                     </div>

//                     <div className="flex items-center justify-center gap-x-6 border-t border-gray-900/10 px-4 py-4 sm:px-8">
//                         <button
//                             type="button"
//                             className="text-sm font-semibold text-white bg-red-500 px-4 py-2 rounded-md hover:bg-red-600 transition ease-in-out duration-300"
//                         >
//                             Cancel
//                         </button>
//                         <button
//                             type="submit"
//                             className="rounded-md bg-indigo-600 px-6 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
//                         >
//                             Save
//                         </button>

//                     </div>
//                 </form>
//             </div>

//             <PrescriptionTable allMedicines={watch("medical")} prescriptionAlldata={watch("")} />

//             {/* <PrescriptionTable
//                 allMedicines={watch("medical")}
//                 patient={prescriptionAlldata?.result?.map(patient => patient._id) || []}
//             /> */}




//         </>
//     );
// };

// export default Prescription;
