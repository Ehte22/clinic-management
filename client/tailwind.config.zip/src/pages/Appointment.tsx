import { useState } from 'react'
import { IData, useDeleteAppointmentMutation, useSearchAppointmentsQuery } from '../redux/apis/appointment.api'
import { ColumnDef, PaginationState } from '@tanstack/react-table';
import TableData from '../components/TableData';
import { useNavigate } from 'react-router-dom';

const Appointment = () => {

    const [searchQuery, setSearchQuery] = useState("");
    const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 5 });

    const { data: searchData } = useSearchAppointmentsQuery({
        query: searchQuery,
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
    })


    const [deleteAppointment] = useDeleteAppointmentMutation()
    const navigate = useNavigate()

    const handleDeleteAppointment = async (appointmentId: string) => {
        if (confirm('Are you sure you want to delete this appointment?')) {
            try {
                await deleteAppointment(appointmentId).unwrap();
                alert('Appointment deleted successfully!');
            } catch (error) {
                console.error('Error deleting appointment:', error);
                alert('Failed to delete appointment.');
            }
        }
    };



    const columns: ColumnDef<IData>[] = [
        {
            accessorKey: 'patient.name',
            cell: (info) => info.getValue(),
            header: 'Patient Name',
        },
        {
            accessorKey: 'patient.email',
            cell: (info) => info.getValue(),
            header: 'Patient Email',
        },
        {
            accessorKey: 'patient.contactInfo',
            cell: (info) => info.getValue(),
            header: 'Patient mobile',
        },
        // {
        //     accessorKey: 'clinic.name',
        //     cell: (info) => info.getValue(),
        //     header: 'Clinic Name',
        // },
        // {
        //     accessorKey: 'clinic.city',
        //     cell: (info) => info.getValue(),
        //     header: 'Clinic Address',
        // },
        {
            header: "Doctor Name",
            cell: (info) => {
                const row = info.row.original;
                return `${row.doctor.doctor.firstName} ${row.doctor.doctor.lastName}`;
            },

            enableSorting: false
        },

        {
            header: "Time Slot",
            cell: (info) => {
                const row = info.row.original;
                return `From: ${row.timeSlot.from} To: ${row.timeSlot.to}`;
            },
            accessorKey: "doctor.firstName",
            enableSorting: false
        },

        {
            accessorKey: 'status',
            cell: (info) => info.getValue(),
            header: 'Status',
        },
        {
            accessorKey: 'action',
            cell: (info) => (
                <button
                    onClick={() => handleDeleteAppointment(info.row.original._id)}
                    className="text-red-600 hover:text-red-800"
                >
                    Delete
                </button>
            ),
            header: 'Acton',
        },

        {
            header: "update",
            cell: (info) => {
                const row = info.row.original;
                const navigate = useNavigate()

                return (
                    <button
                        className="text-indigo-600 hover:text-indigo-900"
                        onClick={() => navigate(`/update-appointment/${row._id}`)}
                    >
                        Edit
                    </button>
                );
            },
        },
    ]




    return <>
        <div className='my-14'>
            <div className="sm:flex sm:items-center">
                <div className="sm:flex-auto">
                    <h2 className="text-lg font-bold text-gray-900">Appointment</h2>
                </div>
                <div className="mt-4 sm:ml-16 sm:mt-0 flex justify-between gap-5">
                    <input
                        type="text"
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search..."
                        className="block w-72 h-10 rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                    />

                    <button
                        type="button"
                        className="block rounded-md bg-indigo-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        onClick={() => navigate("/add-appointment")}
                    >
                        Add
                    </button>
                </div>
            </div>
            {searchData && (
                <TableData<IData>
                    data={searchData?.result || []}
                    columns={columns}
                    enableSorting={true}
                    onPaginationChange={setPagination}
                    enableGlobalFilter={true}

                    onGlobalFilterChange={searchQuery}
                    initialPagination={{ pageIndex: 0, pageSize: pagination.pageSize }}
                    totalPages={searchData?.pagination?.totalPages}
                />
            )}
        </div>
    </>
}

export default Appointment

