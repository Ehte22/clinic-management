import { useEffect, useState } from 'react'
import { customValidator } from '../../utils/validator'
import useDynamicForm from '../../components/useDynamicForm'
import { FieldConfig } from '../../models/fieldConfig.interface';
import { ValidationRules } from '../../models/validationRules.interface';
import { useCreateDoctorMutation, useGetDoctorByIdQuery, useGetDoctorsQuery, useUpdateDoctorMutation } from '../../redux/apis/doctor.api';
import { z } from 'zod';
import { useGetClinicsQuery } from '../../redux/apis/clinic.api';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from '../../utils/toast';




const defaultValues = {
    specialization: "",
    label: "",
    experience_years: "",
    qualifications: "",
    emergency_contact: "",
    doctor: "",
    clinic: "",
    bio: "",
    schedule: [{
        day: "",
        from: "",
        to: "",
    }],
}

export interface ExtractedRule {
    name: string;
    rules: ValidationRules | ExtractedRule[];
}
const AddDoctor = () => {
    const [addUser, { isSuccess: addsuccess, isError: addIsError, error: adderror }] = useCreateDoctorMutation()
    const { data: clinicData } = useGetClinicsQuery({})
    const { data: doctors } = useGetDoctorsQuery()
    const { id } = useParams()

    const { data: singleDoctor } = useGetDoctorByIdQuery(id as string || "", {
        skip: !id,
    })


    const [clinicOptions, setClinicOptions] = useState<{ label: string; value: string }[]>([]);
    const [doctorOptions, setDoctorOptions] = useState<{ label: string; value: string }[]>([]);

    const [updatedoctor, { isSuccess: updateSuccess, isError: updateIserror, error: Updateerror }] = useUpdateDoctorMutation()
    const navigate = useNavigate()

    const onSubmit = (values: FormValues) => {
        console.log(values, 'values');

        let updatedValues: Record<string, any> = {};


        Object.keys(values)?.forEach((key) => {
            // if (key === "qualifications") {
            //     if (values[key].length > 1) {
            //         updatedValues[key] = values[key];
            //     } else {
            //         updatedValues[key] = values[key];
            //     }
            // } else
            if (key === "schedule") {
                updatedValues[key] = values[key].map((item: Record<string, string>, index: number) => {
                    return Object.keys(item).reduce((acc, subKey) => {
                        acc[`${key}[${index}][${subKey}]`] = item[subKey];
                        return acc;
                    }, {} as Record<string, string>);
                });
            } else if (key === "profile") {
                updatedValues[key] = values.profile;
            } else {
                updatedValues[key] = values[key];
            }
        });

        const clinic = clinicData?.result?.find(item => item.name === values.clinic)



        const doctor = doctors?.find(item => item?.firstName === values.doctor)

        updatedValues = { ...updatedValues, ...values, clinic: clinic?._id, doctor: doctor?._id }


        if (id && singleDoctor) {
            updatedoctor({ doctorData: updatedValues, id })
        } else {
            addUser(updatedValues);
        }
    };

    useEffect(() => {
        if (clinicData?.result) {
            const formattedData = clinicData.result?.map((element: any) => ({
                label: element.name,
                value: element.name,

            }));

            setClinicOptions(formattedData);
        }
    }, [clinicData?.result]);
    useEffect(() => {
        if (addsuccess) {
            navigate("/doctor")
        }
    }, [addsuccess]);

    useEffect(() => {
        if (updateSuccess) {
            navigate("/doctor")
        }
    }, [updateSuccess]);

    useEffect(() => {
        if (doctors) {


            const doctorData = doctors?.map((element: any) => ({

                label: element?.firstName,
                value: element?.firstName,
            }));
            setDoctorOptions(doctorData);
        }
    }, [doctors]);


    useEffect(() => {
        if (id && singleDoctor) {

            setValue("doctor", singleDoctor?.doctor.firstName)
            setValue("clinic", singleDoctor?.clinic.name)
            setValue("specialization", singleDoctor?.specialization)
            setValue("emergency_contact", singleDoctor?.emergency_contact)
            setValue("label", singleDoctor?.label)
            setValue("bio", singleDoctor?.bio)
            setValue("experience_years", singleDoctor?.experience_years)
            setValue("qualifications", singleDoctor?.qualifications)
            if (singleDoctor?.schedule) {
                const updatedSchedule = singleDoctor.schedule.map((item: any) => ({
                    day: item.day,
                    from: item.from,
                    to: item.to,
                }));
                setValue("schedule", updatedSchedule);
            }
        }
    }, [singleDoctor])


    useEffect(() => {
        if (addsuccess) {
            toast.showSuccess("Add Doctor Success")
        }
        if (updateSuccess) {
            toast.showSuccess("Update Doctor Success")
        }

        if (addIsError) {
            toast.showError(adderror as string)
        }
        if (updateIserror) {
            toast.showError(Updateerror as string)
        }

    }, [updateSuccess, addsuccess, addIsError, adderror, updateIserror, Updateerror])





    const fields: FieldConfig[] = [
        {
            name: "specialization",
            label: "Specialization",
            type: "text",
            placeholder: "Enter your Specialization",
            rules: { required: false, min: 2, max: 16 }
        },
        {
            name: "label",
            label: "Label",
            type: "text",
            placeholder: "Enter your Label",
            rules: { required: false, min: 2, max: 16 }
        },
        {
            name: "experience_years",
            label: "Experience Years",
            type: "text",
            placeholder: "Enter your experience years",
            rules: { required: false, }
        },
        {
            name: "emergency_contact",
            label: "Emergency Contact",
            type: "text",
            placeholder: "Enter your Emergency Contact",
            rules: { required: false, pattern: /^[6-9]\d{9}$/ }
        },
        {
            name: "qualifications",
            label: "Qualifications",
            placeholder: "Enter Qualifications",
            type: "text",
            rules: { required: false, }
        },
        {
            name: "doctor",
            label: "Doctor",
            type: "searchSelect",
            options: [{ label: "Select Doctor", value: "", disabled: true }, ...doctorOptions],
            rules: { required: true }
        },
        {
            name: "clinic",
            label: "Clinic",
            type: "searchSelect",
            options: [{ label: "select Clinic", value: "", disabled: true }, ...clinicOptions],
            rules: { required: true }
        },
        {
            name: "bio",
            label: "Bio",
            type: "textarea",
            placeholder: "Enter text here",
            rows: 4,
            rules: { required: false, min: 5, max: 100 }
        },
        {
            name: "button",
            displayName: "Add User",
            type: "submit",
            className: "btn btn-dark text-end my-3 me-4",
            rules: {}
        },
        {
            name: "schedule",
            displayName: "schedule",
            type: "formArray",
            className: "border px-4 py-6 sm:p-8 my-4",
            formArray: [
                {
                    name: "day",
                    label: "Day",
                    options: [
                        { label: "Select Day", name: "Select Day", disabled: true },
                        { label: "monday", name: "monday", value: "monday" },
                        { label: "tuesday", name: "tuesday", value: "tuesday" },
                        { label: "wednesday", name: "wednesday", value: "wednesday" },
                        { label: "thursday", name: "thursday", value: "thursday" },
                        { label: "friday", name: "friday", value: "friday" },
                        { label: "saturday", name: "saturday", value: "saturday" },
                        { label: "sunday", name: "sunday", value: "sunday" },
                    ],
                    placeholder: "Enter Day",
                    type: "select",
                    className: "sm:col-span-6 xl:col-span-4",
                    rules: { required: false }
                },
                {
                    name: "from",
                    label: "From",
                    type: "time",
                    className: "sm:col-span-6 xl:col-span-4",
                    rules: { required: false }
                },
                {
                    name: "to",
                    label: "to",
                    type: "time",
                    className: "sm:col-span-6 xl:col-span-4",
                    rules: { required: false }
                }
            ],
            rules: {}
        },

    ];



    const schema = customValidator(fields)


    type FormValues = z.infer<typeof schema>
    const { renderSingleInput, handleSubmit, setValue, reset } = useDynamicForm({ schema, fields, onSubmit, defaultValues })
    return <>
        <div className="grid grid-cols-1 gap-x-8 gap-y-8">
            <div className="flex justify-between">
                <h2 className="text-lg font-bold text-gray-900">{id ? "Update Doctor" : "Add Doctor"}</h2>
                <button
                    type="button"
                    className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    onClick={() => navigate("/doctor")}
                >
                    Back
                </button>
            </div>
            <form onSubmit={handleSubmit(onSubmit)} className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl">
                <div className="px-4 py-6 sm:p-8">
                    <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('clinic')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('doctor')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('specialization')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('experience_years')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('qualifications')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('label')}
                        </div>
                        <div className="sm:col-span-3 xl:col-span-2">
                            {renderSingleInput('emergency_contact')}
                        </div>
                        <div className="sm:col-span-6 xl:col-span-4">
                            {renderSingleInput('bio')}
                        </div>

                        <div className="sm:col-span-6">
                            {renderSingleInput('schedule')}
                        </div>

                    </div>
                </div>


                <div className="flex items-center justify-end gap-x-3 border-t border-gray-900/10 px-4 py-4 sm:px-8">
                    <button onClick={() => reset()} type="button" className="rounded-md bg-gray-400 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Save
                    </button>
                </div>

            </form>
        </div>
    </>
}

export default AddDoctor