import { useEffect, useState } from 'react';
import { useGetAdminDashboardDataQuery } from '../redux/apis/dashboard.api';
import { Bar, Pie } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement,
} from 'chart.js';
import { Listbox, ListboxButton, ListboxOption, ListboxOptions } from '@headlessui/react';
import { CheckIcon, ChevronUpDownIcon } from '@heroicons/react/16/solid';
import Loader from '../components/Loader';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend
);

const AdminDashboard = () => {

    const [incomeData, setIncomeData] = useState<any>([]);
    const [patientData, setPatientData] = useState<any>([]);

    const currentDate = new Date()
    const currentYear = currentDate.getFullYear()
    const years = Array.from({ length: currentYear - 2021 + 1 }, (_, i) => 2021 + i).reverse();

    const [selectYear, setSelectYear] = useState(years[0])

    const { data: allDashBoardData, isLoading } = useGetAdminDashboardDataQuery({ selectedYear: selectYear });

    useEffect(() => {
        if (allDashBoardData) {
            if (allDashBoardData.patients) {
                setPatientData(allDashBoardData.patients);
            }

            if (allDashBoardData.income) {
                setIncomeData(allDashBoardData.income)
            }
        }
    }, [allDashBoardData, patientData, incomeData]);

    const patientOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top' as const,
            },
            title: {
                display: true,
                text: 'Patients',
                font: {
                    size: 16
                }
            },
        },
        scales: {
            x: {
                ticks: {
                    font: {
                        size: 11
                    }
                }
            },
            y: {
                beginAtZero: true,
                ticks: {
                    font: {
                        size: 11
                    },
                    stepSize: 10
                },
            }
        }
    };
    const incomeOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right' as const,
                labels: {
                    font: {
                        size: window.innerWidth < 600 ? 10 : window.innerWidth < 768 ? 12 : 14
                    },
                }
            },
            title: {
                display: true,
                text: 'Income',
                font: {
                    size: 16
                },
                padding: {
                    bottom: 40
                }
            },
        },
    };

    const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const patients = {
        labels,
        datasets: [
            {
                label: 'Old Patients',
                data: patientData.map((item: any) => item.oldPatients),
                backgroundColor: 'rgba(53, 162, 235, 0.5)',
            },
            {
                label: 'New Patients',
                data: patientData.map((item: any) => item.newPatients),
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
            },
        ],
    };

    const income = {
        labels: [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ],
        datasets: [
            {
                label: 'Total Income',
                data: incomeData.map((item: any) => item.totalAmount),
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)', 'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)', 'rgba(255, 159, 64, 0.2)',
                    'rgba(201, 203, 207, 0.2)', 'rgba(0, 128, 128, 0.2)',
                    'rgba(255, 165, 0, 0.2)', 'rgba(127, 255, 212, 0.2)',
                    'rgba(220, 20, 60, 0.2)', 'rgba(46, 139, 87, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
                    'rgba(201, 203, 207, 1)', 'rgba(0, 128, 128, 1)',
                    'rgba(255, 165, 0, 1)', 'rgba(127, 255, 212, 1)',
                    'rgba(220, 20, 60, 1)', 'rgba(46, 139, 87, 1)'
                ],
                borderWidth: 1,
            },
        ],
    };

    if (isLoading) {
        return <div className="flex justify-center items-center h-screen -mt-20">
            <Loader size={16} />
        </div>
    }

    return <>
        <Listbox value={selectYear} onChange={setSelectYear}>
            <div className="relative mt-2 flex justify-end">
                <ListboxButton className="grid w-40 cursor-default grid-cols-1 rounded-md bg-white py-1.5 pl-3 pr-2 text-left text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6">
                    <span className="col-start-1 row-start-1 truncate pr-6">{selectYear}</span>
                    <ChevronUpDownIcon
                        aria-hidden="true"
                        className="col-start-1 row-start-1 size-5 self-center justify-self-end text-gray-500 sm:size-4"
                    />
                </ListboxButton>

                <ListboxOptions
                    transition
                    className="absolute z-10 mt-1 max-h-60 w-40 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black/5 focus:outline-none data-[closed]:data-[leave]:opacity-0 data-[leave]:transition data-[leave]:duration-100 data-[leave]:ease-in sm:text-sm"
                >
                    {years.map((year) => (
                        <ListboxOption
                            key={year}
                            value={year}
                            className="group relative cursor-default select-none py-2 pl-3 pr-9 text-gray-900 data-[focus]:bg-indigo-600 data-[focus]:text-white data-[focus]:outline-none"
                        >
                            <span className="block truncate font-normal group-data-[selected]:font-semibold">{year}</span>

                            <span className="absolute inset-y-0 right-0 flex items-center pr-4 text-indigo-600 group-[&:not([data-selected])]:hidden group-data-[focus]:text-white">
                                <CheckIcon aria-hidden="true" className="size-5" />
                            </span>
                        </ListboxOption>
                    ))}
                </ListboxOptions>
            </div>
        </Listbox>

        <div className='border p-2 md:p-4 xl:p-8 mt-8' >
            <Pie options={incomeOptions} data={income} />
        </div>

        <div className='h-64 sm:h-96 xl:h-[500px] border p-2 md:p-4 xl:p-8 mt-8' >
            <Bar options={patientOptions} data={patients} />
        </div>

    </>
};

export default AdminDashboard;
