import React, { useEffect, useState } from 'react';
import useDynamicForm from '../../components/useDynamicForm';
import { FieldConfig } from '../../models/fieldConfig.interface';
import { customValidator } from '../../utils/validator';
import { useAddMedicineMutation, useGetSingleMedicineQuery, useUpdateMedicineMutation } from '../../redux/apis/medicineApi';
import { toast } from '../../utils/toast';
import { useNavigate, useParams } from 'react-router-dom';
import { useGetSuppliersQuery } from '../../redux/apis/supplier.api';

const fields: FieldConfig[] = [
  { name: 'medicineName', rules: { required: true }, placeholder: "Enter Medicine Name", type: "text", label: "Medicine Name" },
  { name: 'category', rules: { required: true }, placeholder: "Enter Category", type: "text", label: "Category" },
  { name: 'label', rules: { required: false }, placeholder: "Enter Label", type: "text", label: "Label Name" },
  { name: 'expiryDate', rules: { required: true }, placeholder: "Enter Expiry Date", type: "date", label: "Expiry Date" },
  { name: 'stock', rules: { required: true }, placeholder: "Enter Stock", type: "text", label: "Stock" },
  { name: 'mg', rules: { required: true }, placeholder: "Enter MG", type: "text", label: "MG" },
  { name: 'price', rules: { required: true }, placeholder: "Enter Price", type: "text", label: "Price Per Unit" },
  { name: 'medicineType', rules: { required: true }, placeholder: "Enter Medicine Type", type: "text", label: "Medicine Type" },
  // { name: 'quantity', rules: { required: true }, placeholder: "Enter Quantity", type: "text", label: "Quantity" },
  // { name: 'manufacturer', rules: { required: true }, placeholder: "Enter Manufacturer Name", type: "text", label: "Manufacturer Name" },
  // { name: 'batchNumber', rules: { required: true }, placeholder: "Enter Batch Number", type: "text", label: "Batch Number" },
  // { name: 'discount', rules: { required: true }, placeholder: "Enter Discount", type: "text", label: "Discount" },
  // { 
  //   name: 'supplier',
  //    rules: { required: true },
  //     placeholder: "select supplier",
  //      type: "searchSelect",
  //       label: "Supplier",
  //       // options:

  //      },
  // { name: 'purchasedPrice', rules: { required: true }, placeholder: "Enter Purchased Price", type: "text", label: "Purchased Price" },
];

const defaultValues = {
       medicineName: "",
       expiryDate: "",
       stock: "",
       mg: "",
       price: "",
      //  stock: "",
       label: "",
       medicineType: "",
       // manufacturer: "",
       // batchNumber: "",
       // discount: "",
       supplier: "",
       // purchasedPrice: "",

};

const AddMedicine: React.FC = () => {
      const [updatedFields, setUpdatedFields, ] = useState<FieldConfig[]>([...fields]);
      const {data:suppliers, isSuccess: getSupplierSuccess}= useGetSuppliersQuery({isFetchAll:true})

      
  const navigate = useNavigate()
  const schema = customValidator(updatedFields)
  const [AddMedicine, { isSuccess }] = useAddMedicineMutation()
  const [update, { isSuccess: updateSuccess }] = useUpdateMedicineMutation()
  const { id } = useParams()
  const { data } = useGetSingleMedicineQuery(id || "", {
    skip: !id
  })
  const onSubmit = (data: any) => {
    const supplier = suppliers?.result?.find(item => item.name === data.supplier)


    if (id) {
      update({ ...data, _id: id, supplier:supplier?._id })
    } else {
      AddMedicine({...data, supplier: supplier?._id})
      
    }
  };

  const { renderSingleInput, handleSubmit, setValue, reset } = useDynamicForm({
    schema,
    fields: updatedFields,
    onSubmit,
    defaultValues,
  });


      useEffect(() => {
          if (getSupplierSuccess && suppliers ) {
              const clinics = suppliers.result.map((item) => ({
                  label: item.name,
                  value: item.name
              }));
           const copy:any = [...updatedFields,
            {
                name: "supplier",
                label: "Supplier",
                type: "searchSelect",
                options: [
                    { label: "Select Supplier", value: "", disabled: true },
                    ...clinics
                ],
                rules: { required: true }
            }
        ]
        setUpdatedFields(copy)
        
              // setUpdatedFields([
              //     ...fields,
              //     {
              //         name: "supplier",
              //         label: "Supplier",
              //         type: "searchSelect",
              //         options: [
              //             { label: "Select Supplier", value: "", disabled: true },
              //             ...clinics
              //         ],
              //         rules: { required: true }
              //     }
              // ]);
              
          } else {
              setUpdatedFields(fields.filter((field) => field.name !== "supplier"));
          }
      }, [suppliers, getSupplierSuccess, fields]);
// console.log(updatedFields,"FROM OUTER");

  useEffect(() => {
    if (id && data) {
      // console.log("hgfhgfkg",data);

      setValue("medicineName", data.medicineName)
      setValue("category", data.category)
      setValue("label", data.label)
      // setValue("manufacturer", data.manufacturer)
      setValue("expiryDate", data.expiryDate)
      setValue("stock", data.stock)
      // setValue("batchNumber", data.batchNumber)
      setValue("mg", data.mg.toString() || "")
      setValue("price", data.price)
      // setValue("discount", data.discount)
      setValue("supplier", data.supplier)
      // setValue("purchasedPrice", data.purchasedPrice)
      setValue("stock", data.stock)
      // setValue("clinicId", data.clinicId)
      setValue("medicineType", data.medicineType)

    }
  }, [id, data])

  useEffect(() => {
    if (isSuccess) {
      toast.showSuccess("Medicine Added Success")
      navigate("/all-medicines")
      reset()
    }
  }, [isSuccess])
  useEffect(() => {
    if (updateSuccess) {
      toast.showSuccess("Medicine Update Success")
      reset()
      navigate("/all-medicines")
    }
  }, [updateSuccess])

  return <>
    <div className="grid grid-cols-1 gap-x-8 gap-y-8">
      <div className="flex justify-between">
        {/* <h2 className="text-lg font-bold text-gray-900">{id ? "Update Clinic" : "Add Clinic"}</h2> */}
        <h2 className="text-lg font-bold text-gray-900">Add Medicine</h2>
        <button
          type="button"
          className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          onClick={() => navigate("/all-medicines")}
        >
          Back
        </button>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl">
        <div className="px-4 py-6 sm:p-8">
          <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">

            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("medicineName")}
            </div>

            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("category")}
            </div>


            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("mg")}
            </div>


            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("medicineType")}
            </div>
            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("label")}
            </div>
            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("expiryDate")}
            </div>
          
            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("price")}
            </div>
            <div className="sm:col-span-3 xl:col-span-2">
              {renderSingleInput("stock")}
            </div>
            <div className="sm:col-span-3 xl:col-span-2">
               {renderSingleInput("supplier")}
               {/* <p>Hello</p> */}
            </div>

          </div>
        </div>

        <div className="flex items-center justify-end gap-x-6 border-t border-gray-900/10 px-4 py-4 sm:px-8">
          <button type="button" onClick={() => navigate("/all-medicines")} className="rounded-md bg-gray-400 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
            Cancel
          </button>
          <button
            type="submit"
            className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  </>

  //   return (
  //     <div className=" mt-20 border-2 rounded-xl   sidebar-hide">
  //     <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 sidebar-hide">
  //         {/* Form Header */}
  //         {/* <div className="text-center border-b p-5 bg-gray-100 rounded-t-xl">
  //             <h1 className="text-4xl font-bold font-mono text-indigo-600">
  //                 Add Medicine
  //             </h1>
  //             <p className="text-gray-500 mt-2">Fill in the details below to add a new medicine</p>
  //         </div> */}

  //         {/* Form Inputs */}
  //         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
  //         </div>

  //         {/* Submit Button */}
  //         <div className="text-center bg-gray-100 rounded-b-xl py-5">
  //             <button
  //                 type="submit"
  //                 className="rounded-lg bg-indigo-600 px-5 py-3 text-base font-semibold text-white shadow-md hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
  //             >
  //                 Add Medicine
  //             </button>
  //         </div>
  //     </form>
  // </div>

  //   );
};

export default AddMedicine;
