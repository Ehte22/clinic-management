import { BrowserRouter, Route, Routes } from "react-router-dom"
import Clinics from "./pages/clinic/Clinics"
import AddClinic from "./pages/clinic/AddClinic"
import Users from "./pages/user/Users"
import AddUser from "./pages/user/AddUser"
import { createContext, useState } from "react"
import AddMedicine from "./pages/medicine/AddMedicine"
import Medicines from "./pages/medicine/Medicines"
import Layout from "./share/Layout"
import Profile from "./pages/user/Profile"
import Invoice from "./pages/invoice/Invoice"
import AddInvoice from "./pages/invoice/AddInvoice"
import Receptionist from "./pages/receptionist/Receptionist"
import AddReceptionist from "./pages/receptionist/AddReceptionist"
import Doctor from "./pages/doctor/Doctor"
import Appointment from "./pages/appointment/Appointment"
import Login from "./pages/Login"
import AddDoctor from "./pages/doctor/AddDoctor"
import AddAppointment from "./pages/appointment/AddAppointment"
import ResetPassword from "./pages/ResetPassword"
import ForgotPassword from "./pages/ForgotPassword"

import Patient from "./pages/Patient"
import Prescription from "./pages/prescription/Prescription"
import PatientTable from "./components/patient/PatientTable"
import './i18n';
import AdminDashboard from "./pages/AdminDashBoard"
import Suppliers from "./pages/supplier/Suppliers"
import AddSupplier from "./pages/supplier/AddSupplier"
import SellMedicine from "./pages/medicine/SellMedicine"

interface ImagePreviewContextType {
  previewImages: string[];
  setPreviewImages: (images: string[]) => void;
}
export const ImagePreviewContext = createContext<ImagePreviewContextType>({
  previewImages: [],
  setPreviewImages: () => { }
})

const App = () => {
  const [previewImages, setPreviewImages] = useState<string[]>([])

  return <>
    <ImagePreviewContext.Provider value={{ previewImages, setPreviewImages }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<AdminDashboard />} />
            {/* user */}
            <Route path="/users" element={<Users />} />
            <Route path="/add-user" element={<AddUser />} />
            <Route path="/update-user/:id" element={<AddUser />} />
            <Route path="/profile/:id" element={<Profile />} />

            {/* clinic */}
            <Route path="/clinics" element={<Clinics />} />
            <Route path="/add-clinic" element={<AddClinic />} />
            <Route path="/update-clinic/:id" element={<AddClinic />} />

            {/* medicine */}
            <Route path="all-medicines" element={<Medicines />} />
            <Route path="buy-med" element={<SellMedicine />} />
            <Route path="add-medicine" element={<AddMedicine />} />
            <Route path="update-medicine/:id" element={<AddMedicine />} />

            {/* invoice */}
            <Route path="invoice" element={<Invoice />} />
            <Route path="add-invoice" element={<AddInvoice />} />
            <Route path="update-invoice/:id" element={<AddInvoice />} />

            {/* receptionist */}
            <Route path="receptionist" element={<Receptionist />} />
            <Route path="add-receptionist" element={<AddReceptionist />} />
            <Route path="update-receptionist/:id" element={<AddReceptionist />} />

            {/* doctor */}
            <Route path="/doctor" element={<Doctor />} />
            <Route path="/add-doctor" element={<AddDoctor />} />
            <Route path="/update-doctor/:id" element={<AddDoctor />} />

            {/* appointment */}
            <Route path="/appointment" element={<Appointment />} />
            <Route path="/add-appointment" element={<AddAppointment />} />
            <Route path="/update-appointment/:id" element={<AddAppointment />} />

            {/* patient */}
            <Route path="/patients" element={<PatientTable />} />
            <Route path="/patient" element={<Patient />} />
            <Route path="/patient/:id" element={<Patient />} />

            {/* prescription */}
            <Route path="/prescription" element={<Prescription />} />

            {/* Supplier */}
            <Route path="/suppliers" element={<Suppliers />} />
            <Route path="/add-supplier" element={<AddSupplier />} />
            <Route path="/update-supplier/:id" element={<AddSupplier />} />

          </Route>

          {/* auth */}
          <Route path="/login" element={<Login />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />

        </Routes>
      </BrowserRouter >
    </ImagePreviewContext.Provider >
  </>
}


export default App