import React from 'react'

const Footer:React.FC = () => {
  return (
    <div>
      Footer
    </div>
  )
}

export default Footer
