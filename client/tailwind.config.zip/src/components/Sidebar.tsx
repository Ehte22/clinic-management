import { PlusCircleIcon } from '@heroicons/react/24/outline'
import { Link } from 'react-router-dom'
import { IUser } from '../models/user.interface'

const navigation = [
    { name: 'Dashboard', href: '/', icon: PlusCircleIcon, current: false },
    { name: 'Clinics', href: '/clinics', icon: PlusCircleIcon, current: false },
    { name: 'Users', href: '/users', icon: PlusCircleIcon, current: false },
    { name: 'Medicines', href: '/all-medicines', icon: PlusCircleIcon, current: false },
    { name: 'Invoices', href: '/invoice', icon: PlusCircleIcon, current: false },
    { name: 'Receptionist', href: '/receptionist', icon: PlusCircleIcon, current: false },
    { name: 'Doctors', href: '/doctor', icon: PlusCircleIcon, current: false },
    { name: 'Appointment', href: '/appointment', icon: PlusCircleIcon, current: false },
    { name: 'Prescription', href: '/prescription', icon: PlusCircleIcon, current: false },
    { name: 'Patient', href: '/patients', icon: PlusCircleIcon, current: false },
    { name: 'Supplier', href: '/suppliers', icon: PlusCircleIcon, current: false },
    { name: 'Buy Medicine', href: '/buy-med', icon: PlusCircleIcon, current: false },
]

interface SideBarCompo {
    toggleSidebar:() => void
    userData?: IUser
}

const Sidebar: React.FC<SideBarCompo> = ({ toggleSidebar , userData}) => {

    const tabView = window.innerWidth < 1024

    const handleToggleSideBar = () => {
        if (tabView) {
            toggleSidebar()
        }
    }

    return <>
        <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-gray-900 px-6 w-80 h-screen fixed scrollbar-hide">
            <div className="flex h-16 shrink-0 items-center">
                <span className='text-white'>LOGO</span>
            </div>
            <nav className="flex flex-1 flex-col">
                <ul role="list" className="flex flex-1 flex-col gap-y-7">
                    <li>
                        <ul role="list" className="-mx-2 space-y-1" >
                            {navigation.map((item) => (
                                <li key={item.name}>
                                    <Link
                                        to={item.href}
                                        onClick={handleToggleSideBar}
                                        className='text-gray-400 hover:bg-gray-800 hover:text-white group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold'

                                    >
                                        <item.icon aria-hidden="true" className="size-6 shrink-0" />
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </li>
                    <li className="-mx-6 mt-auto">
                        <Link
                           to={`/profile/${userData?._id}`}
                            className="flex items-center gap-x-4 px-6 py-3 text-sm/6 font-semibold text-white hover:bg-gray-800"
                        >
                            <img
                                alt={userData?.firstName}
                                src={`${userData?.profile}` ? userData?.profile : "/profile.png"}
                                className="size-8 rounded-full bg-gray-800"
                            />
                            <span className="sr-only">{userData?.firstName} {userData?.lastName}</span>
                            <span aria-hidden="true">{userData?.firstName} {userData?.lastName}</span>
                        </Link>
                    </li>
                </ul>
            </nav>
        </div>
    </>
}

export default Sidebar





// import React from 'react';
// import { useSelector } from 'react-redux';
// import { Link } from 'react-router-dom';
// import {
//   CalendarIcon,
//   ChartPieIcon,
//   DocumentDuplicateIcon,
//   FolderIcon,
//   UsersIcon,
//   PlusCircleIcon
// } from '@heroicons/react/24/outline';
// // import { RootState } from '../redux/store';


// type Role = 'admin' | 'doctor' | 'receptionist';

// interface User {
//   role?: Role;
//   name?: string;
// }

// interface RootState {
//   auth: {
//     user: User | null;
//   };
// }
// // Utility to generate class names dynamically
// function classNames(...classes: any) {
//   return classes.filter(Boolean).join(' ');
// }

// const roleBasedNavigation: Record<Role, Array<{
//     name: string;
//     href: string;
//     icon: React.ForwardRefExoticComponent<
//       Omit<React.SVGProps<SVGSVGElement>, 'ref'> & {
//         title?: string;
//         titleId?: string;
//       } & React.RefAttributes<SVGSVGElement>
//     >;
//     count?: string;
//     current: boolean;
//   }>> = {
//     admin: [
//       { name: 'Add Medicine', href: '/add-medicine', icon: PlusCircleIcon, count: '5', current: false },
//       { name: 'All Medicines', href: '/all-medicines', icon: PlusCircleIcon, current: false },
//       { name: 'Manage Users', href: '/manage-users', icon: UsersIcon, current: false },
//       { name: 'Reports', href: '/reports', icon: ChartPieIcon, current: false },
//     ],
//     doctor: [
//       { name: 'Calendar', href: '/calendar', icon: CalendarIcon, count: '20+', current: false },
//       { name: 'Patient Records', href: '/patient-records', icon: FolderIcon, current: false },
//       { name: 'Documents', href: '/documents', icon: DocumentDuplicateIcon, current: false },
//     ],
//     receptionist: [
//       { name: 'Schedule Appointments', href: '/appointments', icon: CalendarIcon, current: false },
//       { name: 'Manage Patients', href: '/manage-patients', icon: UsersIcon, current: false },
//       { name: 'Reports', href: '/reports', icon: ChartPieIcon, current: false },
//     ],
//   };
  
//   const Sidebar = () => {
//     // const user = useSelector((state: RootState) => state.auth.user);
//     const user = {
//         role: "admin"
//     }
  
//     // TypeScript knows that user?.role must match a key in roleBasedNavigation
//     const navigation = user?.role ? roleBasedNavigation[user.role] : [];
  
//     return (
//       <div className="md:flex grow flex-col gap-y-5 overflow-y-auto bg-gray-900 px-6 w-80 h-screen fixed scrollbar-hide">
//         <div className="flex h-16 shrink-0 items-center">
//           <span className="text-white">LOGO</span>
//         </div>
//         <nav className="flex flex-1 flex-col">
//           <ul role="list" className="flex flex-1 flex-col gap-y-7">
//             <li>
//               <ul role="list" className="-mx-2 space-y-1">
//                 {navigation.map((item) => (
//                   <li key={item.name}>
//                     <Link
//                       to={item.href}
//                       className={classNames(
//                         item.current
//                           ? 'bg-gray-800 text-white'
//                           : 'text-gray-400 hover:bg-gray-800 hover:text-white',
//                         'group flex gap-x-3 rounded-md p-2 text-sm/6 font-semibold',
//                       )}
//                     >
//                       <item.icon aria-hidden="true" className="h-6 w-6 shrink-0" />
//                       {item.name}
//                       {item.count ? (
//                         <span
//                           aria-hidden="true"
//                           className="ml-auto w-9 min-w-max whitespace-nowrap rounded-full bg-gray-900 px-2.5 py-0.5 text-center text-xs/5 font-medium text-white ring-1 ring-inset ring-gray-700"
//                         >
//                           {item.count}
//                         </span>
//                       ) : null}
//                     </Link>
//                   </li>
//                 ))}
//               </ul>
//             </li>
//             <li className="-mx-6 mt-auto">
//               <a
//                 href="#"
//                 className="flex items-center gap-x-4 px-6 py-3 text-sm/6 font-semibold text-white hover:bg-gray-800"
//               >
//                 <img
//                   alt=""
//                   src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
//                   className="h-8 w-8 rounded-full bg-gray-800"
//                 />
//                 <span className="sr-only">Your profile</span>
//                 {/* <span aria-hidden="true">{user?.name || 'User'}</span> */}
//                 <span aria-hidden="true">{user?.role || 'User'}</span>
//               </a>
//             </li>
//           </ul>
//         </nav>
//       </div>
//     );
//   };
  
//   export default Sidebar;